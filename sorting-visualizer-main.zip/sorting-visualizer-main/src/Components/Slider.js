import React from 'react'

function Slider() {
    return (
        <div>
            <input type="range" min="1" max="100" value="10" class="slider" id="myRange"></input>
        </div>
    )
}

export default Slider
