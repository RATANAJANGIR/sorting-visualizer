# Sorting-visualizer
This is a web-app to visualize how sorting algorithms work.
